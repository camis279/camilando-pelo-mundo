# Camilando Pelo Mundo — site inicial

Este é um site estático feito com HTML, CSS e JavaScript, preparado para você editar e publicar.

## O que está incluído
- `index.html`: página inicial
- `styles.css`: identidade visual e layout responsivo
- `script.js`: menu móvel, ano automático e mensagem demonstrativa do formulário
- `sobre.html`: página Sobre
- `contato.html`: página de contato de exemplo
- `privacidade.html`: estrutura inicial de política de privacidade
- `artigos/`: três páginas de artigo-modelo

## Como visualizar
1. Descompacte o ZIP.
2. Abra a pasta no Visual Studio Code.
3. Abra `index.html` no navegador. Para uma experiência melhor, instale a extensão Live Server no VS Code e escolha “Open with Live Server”.

## Como editar
- Textos e estrutura: arquivos `.html`
- Cores, fontes, espaçamentos e layout: `styles.css`
- Comportamentos de interface: `script.js`
- Imagens: altere as URLs `images.unsplash.com` nos arquivos HTML/CSS ou use imagens próprias otimizadas.

## Publicar no GitHub Pages
1. Crie uma conta em https://github.com/
2. Crie um repositório novo, por exemplo `camilando-pelo-mundo`.
3. Envie todos os arquivos e pastas deste projeto (não envie apenas `index.html`).
4. No repositório, entre em Settings → Pages.
5. Em “Build and deployment”, selecione “Deploy from a branch”, escolha `main` e `/ (root)` e salve.
6. Aguarde o endereço publicado aparecer na seção Pages.

A documentação oficial fica em https://docs.github.com/en/pages.
Para domínio próprio, registre um domínio e configure DNS conforme a documentação do serviço.

## Antes de lançar
- Troque o texto de exemplo da página Sobre por sua história real.
- Atualize o e-mail de contato em `contato.html`.
- Substitua links de redes sociais com `href="#"`.
- O formulário de newsletter é apenas visual/demonstrativo e NÃO guarda endereços. Conecte um provedor de newsletter antes de coletar e-mails.
- A página de privacidade é apenas um modelo inicial, não aconselhamento jurídico. Ajuste-a aos serviços e dados realmente usados.
- Confirme direitos/licenças das imagens e substitua por fotos próprias sempre que possível.
- Adicione favicon, sitemap.xml, robots.txt, analytics com consentimento quando aplicável e metadados sociais.
- Configure domínio, HTTPS e testes em celular.
- Identifique links de afiliados e conteúdos patrocinados de forma clara.

## Monetização
1. Afiliados: candidate-se a programas relevantes para viagens e insira links rastreáveis e identificados.
2. Parcerias: crie uma página de mídia kit com audiência, perfil do público e formatos de publicidade.
3. Anúncios: só aplique quando o blog atender aos requisitos do fornecedor.
4. Produtos próprios: guias PDF, roteiros personalizados e checklists.

Não existe garantia de aprovação ou renda; programas têm critérios próprios e exigem transparência com o público.
