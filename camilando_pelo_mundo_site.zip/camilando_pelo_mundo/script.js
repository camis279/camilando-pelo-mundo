// Interações leves do site. O formulário de newsletter é demonstrativo até ser conectado a um serviço.
const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');

if (menuToggle && mainNav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = mainNav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });
  mainNav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mainNav.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
    });
  });
}

const year = document.querySelector('#year');
if (year) year.textContent = new Date().getFullYear();

const newsletterForm = document.querySelector('#newsletter-form');
if (newsletterForm) {
  newsletterForm.addEventListener('submit', event => {
    event.preventDefault();
    const message = document.querySelector('#form-message');
    if (message) {
      message.textContent = 'Obrigada pelo interesse! Este formulário ainda não salva e-mails. Antes de publicar, conecte-o a um serviço de newsletter.';
      message.classList.add('form-message-success');
    }
  });
}
